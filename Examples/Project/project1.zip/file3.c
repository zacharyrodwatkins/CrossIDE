#include "header1.h"

void test2 (char a)
{
	char i;
	for(i=0; i<a; i++);
}
