void test1 (void)
{
	int j;
	for (j=0; j<10; j++);
}
